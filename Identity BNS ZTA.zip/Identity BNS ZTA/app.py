from flask import Flask, render_template, request, session, redirect, jsonify, url_for 
from flask_socketio import SocketIO
import random, string, smtplib, json, os, threading, webbrowser
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


print("CURRENT WORKING DIR:", os.getcwd())
app = Flask(__name__)
app.secret_key = "zta_secret_key"
socketio = SocketIO(app, async_mode="threading")
app.secret_key = "mysecret123"
app.secret_key = "supersecretkey123"
app.secret_key = "supersecretkey"
otp_store = {}

# ---------------- LOAD USERS (FIXED) ----------------
if os.path.exists("users.json"):
    with open("users.json", "r") as f:
        users = json.load(f)
else:
    users = {}

otp_store = {}

print("Loaded users:", users)  # DEBUG
import json, os

USER_FILE = "users.json"

def load_users():
    if os.path.exists(USER_FILE):
        with open(USER_FILE, "r") as f:
            return json.load(f)
    return {}

def save_users(users):
    with open(USER_FILE, "w") as f:
        json.dump(users, f)

users = load_users()

# ---------------- DATABASE (simple memory for now) ----------------
visits = 0
login_logs = []

# ---------------- CAPTCHA ----------------
def generate_captcha():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

# ---------------- OTP ----------------
def generate_otp():
    return str(random.randint(100000, 999999))

# ---------------- EMAIL ----------------
def send_email(to, subject, message):
    sender_email = "nnyashac19@gmail.com"
    sender_password = "akksgusoenjfjfst"

    msg = f"Subject: {subject}\n\n{message}"

    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, to, msg)
        server.quit()
        print("Email sent:", to)
    except Exception as e:
        print("Email error:", e)

# ---------------- HOME ----------------
@app.route("/")
def home():
    session["captcha"] = generate_captcha()
    return render_template("index.html", captcha=session["captcha"])

# ---------------- CAPTCHA REFRESH ----------------
@app.route("/refresh_captcha")
def refresh_captcha():
    session["captcha"] = generate_captcha()
    return jsonify({"captcha": session["captcha"]})

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"].strip()
        email = request.form["email"].strip().lower()
        password = request.form["password"].strip()

        otp = generate_otp()
        otp_store[email] = otp

        session["temp_user"] = {
            "username": username,
            "email": email,
            "password": password
        }

        send_email(email, "Register OTP", otp)

        # ✅ NO redirect
        return render_template("register.html", step="otp")

    return render_template("register.html", step="form", captcha=generate_captcha())


@app.route("/verify_register_otp", methods=["POST"])
def verify_register_otp():
    otp = request.form["otp"]
    temp_user = session.get("temp_user")

    if not temp_user:
        return "Session expired"

    email = temp_user["email"]

    if otp_store.get(email) == otp:
        users[email] = temp_user
        otp_store.pop(email)
        session.pop("temp_user")

        return redirect("/login")   # 👉 move to login

    return "Invalid OTP"

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":

        email = request.form["email"].strip().lower()
        password = request.form["password"]
        captcha = request.form["captcha"]

        # CAPTCHA check
        if captcha != session.get("captcha"):
            return render_template("login.html", step="login", captcha=session.get("captcha"), error="Invalid CAPTCHA")

        user = users.get(email)

        if not user:
            return render_template("login.html", step="login", captcha=session.get("captcha"), error="User not found")

        if user["password"] != password:
            return render_template("login.html", step="login", captcha=session.get("captcha"), error="Wrong password")

        # ✅ OTP GENERATION
        otp = str(random.randint(100000, 999999))
        otp_store[email] = otp

        session["login_email"] = email

        send_email(email, "Login OTP", f"Your OTP is {otp}")

        print("LOGIN SUCCESS - OTP SENT:", email)

        # 🔥 IMPORTANT: MUST RETURN OTP STEP
        return render_template("login.html", step="login_otp", email=email)

    # GET REQUEST
    captcha = generate_captcha()
    session["captcha"] = captcha

    return render_template("login.html", step="login", captcha=captcha)



@app.route("/verify_login_otp", methods=["POST"])
def verify_login_otp():
    otp = request.form["otp"]
    email = session.get("login_email")

    if not email:
        return redirect("/login")

    # ✅ correct OTP
    if otp_store.get(email) == otp:
        otp_store.pop(email)

        # 🔥 GO TO DASHBOARD PAGE
        return render_template("dashboard.html", email=email)

    # ❌ wrong OTP → stay on OTP screen inside login.html
    return render_template(
        "login.html",
        step="login_otp",
        email=email,
        error="Invalid OTP"
    )

def send_otp_email(to_email, otp):
    sender_email = "nnyashac19@gmail.com"
    app_password = "akksgusoenjfjfst"

    msg = MIMEText(f"Your OTP code is: {otp}")
    msg["Subject"] = "OTP Verification"
    msg["From"] = sender_email
    msg["To"] = to_email

    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, app_password)
        server.send_message(msg)
        server.quit()

        print("OTP SENT SUCCESS")

    except Exception as e:
        print("EMAIL ERROR:", e)


# ---------------- FORGOT PASSWORD ----------------
# ---------------- PAGE ----------------
@app.route("/forgot-password")
def forgot_password():
    return render_template("forgot_password.html")

# ---------------- SEND OTP ----------------
@app.route("/send-reset-otp", methods=["POST"])
def send_reset_otp():
    username = request.form.get("username")
    email = request.form.get("email")

    if not email:
        return "Email missing", 400

    # 1. Generate OTP
    otp = str(random.randint(100000, 999999))

    # 2. Store OTP temporarily
    otp_store[email] = otp

    # 3. Send email
    send_otp_email(email, otp)

    print("OTP sent to:", email, "OTP:", otp)  # debug only

    return "OTP sent", 200

# ---------------- VERIFY OTP ----------------
@app.route("/verify-reset-otp", methods=["POST"])
def verify_reset_otp():
    user_otp = request.form.get("otp")
    real_otp = session.get("reset_otp")
    email = session.get("reset_email")

    print("DEBUG:", user_otp, real_otp, email)

    if not real_otp or not email:
        return render_template("forgot_password.html", step="reset_email", error="Session expired")

    if user_otp == real_otp:
        session["otp_verified"] = True
        return render_template("forgot_password.html", step="new_password", email=email)

    return render_template("forgot_password.html", step="reset_otp", error="Invalid OTP", email=email)
# ---------------- UPDATE PASSWORD ----------------
@app.route('/set_new_password', methods=['POST'])
def set_new_password():
    email = session.get("reset_email")
    password = request.form.get('password')

    if not email or not session.get("otp_verified"):
        return render_template("index.html", step="login", msg="Unauthorized reset attempt ❌")

    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())

    conn = sqlite3.connect("users.db")
    cur = conn.cursor()

    cur.execute("SELECT * FROM users WHERE email=?", (email,))
    user = cur.fetchone()

    if user:
        cur.execute("UPDATE users SET password=? WHERE email=?", (hashed.decode('utf-8'), email))
        conn.commit()
        msg = "Password Updated Successfully ✅"
    else:
        msg = "Email Not Found ❌"

    conn.close()

    # CLEAR RESET SESSION (IMPORTANT FIX)
    session.pop("reset_email", None)
    session.pop("otp_verified", None)

    return render_template("index.html", step="login", msg=msg)

# ---------------- EMAIL FUNCTION ----------------
def send_otp_email(to_email, otp):
    sender_email = "nnyashac19@gmail.com"
    sender_password = "akksgusoenjfjfst"  # ⚠️ app password format

    msg = MIMEText(f"Your OTP code is: {otp}")
    msg["Subject"] = "Password Reset OTP"
    msg["From"] = sender_email
    msg["To"] = to_email

    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.send_message(msg)
        server.quit()
    except Exception as e:
        print("EMAIL ERROR:", e)

# ---------------- DASHBOARD ----------------
@app.route("/dashboard")
def dashboard():
    if not session.get("logged_in"):
        return redirect("/login")

    return render_template("dashboard.html", user=session.get("user"))

# ---------------- TRACK ----------------

login_logs = []

users_list = ["mel", "Lia","kelvin",  "mimey"]
risks = ["HIGH", "MEDIUM", "LOW"]

from datetime import datetime
import random

login_logs = []

@app.route('/track')
def track():
    log = {
        "ip": f"192.168.1.{random.randint(10,99)}",
        "location": "Punjab",
        "user": random.choice(["mel","kelvin","" "Lia", "mimey"]),
        "status": "ACTIVE",
        "risk": random.choice(["HIGH","MEDIUM","LOW"]),
        "time": datetime.now().strftime("%H:%M:%S")
    }

    login_logs.append(log)

    return "OK"

@app.route('/api/logs')
def get_logs():
    return jsonify(login_logs[-17:])  # only last 17 visits

# ---------------- RUN ----------------
def open_browser():
    webbrowser.open("http://127.0.0.1:5000")

if __name__ == "__main__":
    threading.Timer(1, open_browser).start()
    socketio.run(app, debug=True)